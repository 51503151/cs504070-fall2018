package com.fsoft.fa.ipm.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebApplication extends AbstractSecurityWebApplicationInitializer {

}
