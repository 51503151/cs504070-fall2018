package tdt.it.soa.daos;

import java.util.HashMap;

import tdt.it.soa.models.Item;

public class CartDao {
	public HashMap<String, Item> cartItems;

	
}
