<?php
	session_start();
	unset($_SESSION['shopping_cart']);
?>

Mua h�ng th�nh c�ng!