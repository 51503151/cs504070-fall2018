
        <!---->
        <div class="footer">
            
            <!---->
            <div class="footer-middle">
                <div class="container">
                    <div class="footer-middle-in">
                        <h6>Thông tin</h6>
                        <p>Cửa hàng điện máy được thành lập được 2 tháng, ... </p>
                    </div>
                   
                   
                    <div class="footer-middle-in">
                        <h6>Điều khoản</h6>
                        
                    </div>
                    <div class="footer-middle-in">
                        <h6>Bảo mật</h6>
                        
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <p class="footer-class">Copyright @ 2018</p>
           

        </div>
