<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>banner</title>
    </head>
    <body>

        <div class="banner-mat">
            <div class="container">
                <div class="banner">

                    <!-- Slideshow 4 -->
                    <div class="slider">
                        <ul class="rslides" id="slider1">
                            <li><img src="http://media.kinhtedothi.vn//2018/11/21/xa_hang_giam_gia.jpg" alt="">
                            </li>
                        </ul>
                    </div>

                    <div class="banner-bottom">
                        <div class="banner-matter">
                            <p style="font-weight:900;letter-spacing:5px;text-transform:uppercase;">Mua càng nhiều thưởng càng nhiều!!!</p> 
                         
                        </div>
                        
                        <div class="clearfix"></div>
                    </div>
                </div>				
                <!-- //slider-->
            </div>
        </div>

    </body>
</html>
