<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>register</title>
    </head>
    <body>

         <?php include 'header.php'; ?>

            <div class="container">
                <div class="account">
                    <h2 class="account-in">Register</h2>
                    <form>
                        <div>
                            <span>Username *</span>
                            <input type="text">
                        </div> 	
                        <div> 
                            <span class="word">Password *</span>
                            <input type="password">
                        </div>				
                        <input type="submit" value="Login"> 
                    </form>
                </div>
            </div>

        <?php include 'footer.php'; ?>


    </body>
</html>
