
<!DOCTYPE html>
<html>
   <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>header</title>
			<?php include 'head.php';?>
    </head>
    <body>
		 <?php include 'menubar.php';?>
			
			
    </body>
</html>
